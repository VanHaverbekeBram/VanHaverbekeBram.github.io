const setup = () => {

    let thumbnails = document.getElementById("thumbnails");

};



window.addEventListener("load", setup);