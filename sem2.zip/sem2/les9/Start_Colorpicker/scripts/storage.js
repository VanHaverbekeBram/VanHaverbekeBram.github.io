

const storeSliderValues = () => {

};

const restoreSliderValues = () => {

};

const storeSwatches = () => {
    // bouw een array met kleurinfo objecten
    /*let settings = {};
    let colorJSON;

    settings.red = document.getElementById("sldRed");
    settings.green = document.getElementById("sldGreen");
    settings.blue = document.getElementById("sldBlue");

    colorJSON = JSON.stringify(settings);
    console.log(colorJSON);*/


};

const restoreSwatches = () => {

};
