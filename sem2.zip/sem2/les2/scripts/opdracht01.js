console.log("ALERT", window.alert("Dit is een mededeling"));
console.log("CONFIRM", window.confirm("Weet u het zeker?"));
console.log("PROMPT", window.prompt("Wat is uw naam?"));