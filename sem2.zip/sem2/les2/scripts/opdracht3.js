const setup = () => {
    let pElement = document.getElementById("txtOutput");
    pElement.innerHTML = "Welkom!";
}
let wijzig = document.getElementById("wijzig");
window.addEventListener('click',setup);
